// @vitest-environment jsdom
import React, { useState } from "react";
import "fake-indexeddb/auto";
import { openDB } from "idb";
import { afterEach, expect, it } from "vitest";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  emptySettings,
  settingsSchema,
  missingSettings,
  finalizeVersions,
  parseModelOutput,
} from "../shared/contracts";
import { SettingsPanel } from "../src/components/SettingsPanel";
import { loadDraft, loadHistory } from "../src/storage";
import { freshSession } from "../shared/session";
afterEach(cleanup);
const settings = {
  ...emptySettings(),
  media: ["电影画面"],
  visualStyles: ["柔和光学"],
  colorTone: "自然中性",
  genres: ["生活"],
  culture: "东方",
  realism: "现实世界",
  mood: ["温暖治愈"],
  aspectRatio: "16:9",
  mjVersion: "inherit",
  personalize: "off" as const,
};
const version = {
  title: "窗边",
  zh: {
    opening: "东方生活题材的电影画面，以柔和光学呈现自然中性色调。",
    subject: "两人一起托住窗边的书箱，面部与动作清楚。",
    emotion: "彼此照应的目光传递出温暖安心的氛围。",
  },
  en: {
    opening:
      "An Eastern slice-of-life cinematic frame, with soft optics and a natural neutral palette.",
    subject:
      "Two people support a crate beside a window, with clear faces and actions.",
    emotion: "Their attentive glances create a warm, reassuring mood.",
  },
};
it("requires an explicit mood choice when restoring older drafts and history", async () => {
  const legacy = JSON.parse(
    JSON.stringify({
      ...freshSession(),
      settings,
      versions: [{ title: "旧成品", zh: "旧中文", en: "Old output" }],
    }),
  );
  delete legacy.settings.mood;
  expect(settingsSchema.parse(legacy.settings).mood).toEqual([]);
  expect(missingSettings(settingsSchema.parse(legacy.settings))).toEqual([
    "mood",
  ]);
  const db = await openDB("prompt-director-v1", 1, {
    upgrade(db) {
      db.createObjectStore("draft");
      db.createObjectStore("history", { keyPath: "id" });
    },
  });
  await db.put("draft", legacy, "current");
  await db.put("history", legacy);
  expect((await loadDraft())?.versions).toEqual(legacy.versions);
  expect(
    (await loadHistory()).find((x) => x.id === legacy.id)?.settings.mood,
  ).toEqual([]);
  db.close();
});
it("offers mood chips, explanations, custom combinations and removal without preselection", async () => {
  function Harness() {
    const [s, set] = useState(emptySettings());
    return (
      <SettingsPanel
        settings={s}
        onChange={set}
        onAdvice={() => {}}
        errors={[]}
        disabled={false}
      />
    );
  }
  render(<Harness />);
  const user = userEvent.setup();
  const group = within(screen.getByRole("group", { name: "情绪／氛围" }));
  const warm = group.getByRole("button", { name: "温暖治愈" });
  expect(warm.getAttribute("aria-pressed")).toBe("false");
  await user.hover(warm);
  expect((await screen.findByRole("tooltip")).textContent).toContain(
    "提示词表达示例",
  );
  await user.click(warm);
  await user.click(group.getByRole("button", { name: "亲密默契" }));
  await user.click(group.getByRole("button", { name: "生活化自然" }));
  expect(group.getByRole("button", { name: "移除亲密默契" })).toBeTruthy();
  expect(group.getByRole("button", { name: "移除生活化自然" })).toBeTruthy();
  await user.type(
    group.getByLabelText("搜索情绪／氛围"),
    "孤独但有希望{Enter}",
  );
  expect(group.getByRole("button", { name: "移除孤独但有希望" })).toBeTruthy();
  await user.click(group.getByRole("button", { name: "移除温暖治愈" }));
  expect(
    group
      .getByRole("button", { name: "温暖治愈" })
      .getAttribute("aria-pressed"),
  ).toBe("false");
});
it("assembles each bilingual version as opening, subject, emotion, parameters, then exclusions", () => {
  const result = finalizeVersions([version, version, version], settings, [
    { zh: "路人", en: "passersby" },
  ]);
  for (const item of result)
    for (const lang of ["zh", "en"] as const) {
      expect(item[lang]).toBe(
        [
          version[lang].opening,
          version[lang].subject,
          version[lang].emotion,
          "--ar 16:9",
          `--no ${lang === "zh" ? "路人" : "passersby"}`,
        ].join("\n\n"),
      );
    }
});
it("rejects missing sections, flat legacy model responses, and injected parameters", () => {
  const raw = {
    kind: "prompts",
    versions: [version, version, version],
    negativeTerms: [],
  };
  expect(parseModelOutput(JSON.stringify(raw), "prompts").kind).toBe("prompts");
  expect(() =>
    parseModelOutput(
      JSON.stringify({
        ...raw,
        versions: raw.versions.map((v) => ({
          ...v,
          zh: { ...v.zh, emotion: "" },
        })),
      }),
      "prompts",
    ),
  ).toThrow();
  expect(() =>
    parseModelOutput(
      JSON.stringify({
        ...raw,
        versions: raw.versions.map((v) => ({ ...v, zh: "旧格式" })),
      }),
      "prompts",
    ),
  ).toThrow();
  expect(() =>
    finalizeVersions(
      [
        version,
        version,
        { ...version, en: { ...version.en, subject: "Subject --v 1" } },
      ],
      settings,
      [],
    ),
  ).toThrow();
  expect(() =>
    finalizeVersions([version, version, version], settings, [
      { zh: "路人", en: "passersby --v 1" },
    ]),
  ).toThrow();
  expect(
    finalizeVersions([version, version, version], settings, [])[0].zh,
  ).not.toContain("--no");
});
