import { z } from "zod";
const text = z.string().trim().min(1).max(16000);
export const settingsSchema = z.object({
  media: z.array(text).max(20),
  visualStyles: z.array(text).max(20),
  colorTone: z.string().max(2000).default(""),
  genres: z.array(text).max(20),
  culture: z.string().max(2000),
  realism: z.string().max(2000),
  aspectRatio: z.string().max(50),
  mjVersion: z.string().max(50),
  personalize: z.enum(["", "default", "profile", "off", "inherit"]),
  profileCode: z.string().max(200),
  elements: z.string().max(12000),
  exclusions: z.string().max(6000),
});
export type Settings = z.infer<typeof settingsSchema>;
export type SettingKey =
  | "media"
  | "visualStyles"
  | "colorTone"
  | "genres"
  | "culture"
  | "realism"
  | "aspectRatio"
  | "mjVersion"
  | "personalize";
export const settingKeys: SettingKey[] = [
  "media",
  "visualStyles",
  "colorTone",
  "genres",
  "culture",
  "realism",
  "aspectRatio",
  "mjVersion",
  "personalize",
];
export function emptySettings(): Settings {
  return {
    media: [],
    visualStyles: [],
    colorTone: "",
    genres: [],
    culture: "",
    realism: "",
    aspectRatio: "",
    mjVersion: "",
    personalize: "",
    profileCode: "",
    elements: "",
    exclusions: "",
  };
}
export function missingSettings(s: Settings): SettingKey[] {
  return settingKeys.filter((k) => {
    if (k === "aspectRatio") return !/^[1-9]\d{0,3}:[1-9]\d{0,3}$/.test(s[k]);
    if (k === "mjVersion")
      return s[k] !== "inherit" && !/^\d{1,2}(?:\.\d{1,2})?$/.test(s[k]);
    if (k === "personalize")
      return (
        !s[k] ||
        (s[k] === "profile" &&
          (!/^[a-zA-Z0-9_-]+(?:\s+[a-zA-Z0-9_-]+)*$/.test(
            s.profileCode.trim(),
          ) ||
            s.profileCode.includes("--")))
      );
    const value = s[k];
    return Array.isArray(value)
      ? !value.length
      : !value.replace(/^自定义：/, "").trim();
  });
}
export function parameters(s: Settings) {
  if (missingSettings(s).length) throw new Error("请完成九项设置及所需代码");
  return [
    `--ar ${s.aspectRatio}`,
    s.mjVersion === "inherit" ? "" : `--v ${s.mjVersion}`,
    s.personalize === "default"
      ? "--p"
      : s.personalize === "profile"
        ? `--p ${s.profileCode.trim()}`
        : "",
  ]
    .filter(Boolean)
    .join(" ");
}
export const sceneSchema = z.object({
  id: text,
  title: text,
  location: text,
  event: text,
  interaction: text,
  highlight: text,
  style: text,
  reality: text,
  culture: text,
});
export type Scene = z.infer<typeof sceneSchema>;
export const versionSchema = z.object({ title: text, zh: text, en: text });
export type PromptVersion = z.infer<typeof versionSchema>;
export const clarificationSchema = z.object({
  kind: z.literal("clarification"),
  question: text,
  options: z.array(text).max(5),
  settingField: z.enum(["mjVersion", "personalize"]).nullable().default(null),
});
export type Clarification = z.infer<typeof clarificationSchema>;
export const outputSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("scenes"),
    scenes: z.array(sceneSchema).length(5),
  }),
  z.object({
    kind: z.literal("prompts"),
    versions: z.array(versionSchema).length(3),
  }),
  z.object({ kind: z.literal("advice"), explanation: text, value: text }),
  clarificationSchema,
]);
export type ModelOutput = z.infer<typeof outputSchema>;
export function parseModelOutput(
  raw: string,
  stage: "scenes" | "prompts" | "advice",
): ModelOutput {
  if (!raw.trim()) throw new Error("模型返回空内容，请重试");
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error("模型返回的格式不完整，请重试");
  }
  const result = outputSchema.safeParse(parsed);
  if (!result.success) throw new Error("模型返回内容缺项或数量不符，请重试");
  if (result.data.kind !== stage && result.data.kind !== "clarification")
    throw new Error("模型返回了错误阶段的内容，请重试");
  return result.data;
}
export function finalizeVersions(items: PromptVersion[], s: Settings) {
  const suffix = parameters(s);
  return z
    .array(versionSchema)
    .length(3)
    .parse(items)
    .map((item) => {
      if (/--[a-zA-Z]/.test(item.zh + item.en))
        throw new Error("模型正文混入了未确认参数，请重试");
      return {
        ...item,
        zh: `${item.zh}\n${suffix}`,
        en: `${item.en}\n${suffix}`,
      };
    });
}
export const generationSchema = z.object({
  stage: z.enum(["scenes", "prompts", "advice"]),
  settings: settingsSchema,
  revision: z.number().int().nonnegative(),
  ruleHash: text,
  scene: sceneSchema.nullable().optional(),
  mode: z.enum(["camera", "story"]).nullable().optional(),
  previousScenes: z.array(z.string().max(500)).max(100).default([]),
  amendment: z.string().max(6000).default(""),
  answers: z
    .array(z.object({ question: text, answer: text }))
    .max(20)
    .default([]),
  adviceField: z.enum(["aspectRatio", "mjVersion"]).optional(),
});
export type GenerationRequest = z.infer<typeof generationSchema>;
export type RuleStatus = {
  version: string;
  hash: string;
  synced: boolean;
  changedFiles: string[];
};
export type PublicConfig = { baseUrl: string; model: string; hasKey: boolean };
export type GenerationResponse = {
  output: ModelOutput;
  revision: number;
  ruleHash: string;
  ruleVersion: string;
  model: string;
};
