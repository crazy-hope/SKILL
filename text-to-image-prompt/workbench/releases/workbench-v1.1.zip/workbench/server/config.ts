import { mkdir, readFile, writeFile, rename, chmod } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
const configSchema = z.object({
  baseUrl: z.string(),
  model: z.string().max(200),
  apiKey: z.string().max(2000),
});
export type Config = z.infer<typeof configSchema>;
export function normalizeBaseUrl(value: string) {
  let u: URL;
  try {
    u = new URL(value.trim());
  } catch {
    throw new Error("请输入完整的接口地址");
  }
  if (u.username || u.password || u.search || u.hash)
    throw new Error("接口地址不能包含认证信息或查询参数");
  if (
    u.protocol !== "https:" &&
    !(
      u.protocol === "http:" &&
      ["localhost", "127.0.0.1", "[::1]"].includes(u.hostname)
    )
  )
    throw new Error("非本机接口必须使用 HTTPS");
  return u.toString().replace(/\/$/, "");
}
export async function loadConfig(dir: string): Promise<Config> {
  try {
    return configSchema.parse(
      JSON.parse(await readFile(path.join(dir, "config.json"), "utf8")),
    );
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT")
      return { baseUrl: "https://api.deepseek.com", model: "", apiKey: "" };
    throw new Error("本机模型配置无法读取，请检查配置文件");
  }
}
export function publicConfig(c: Config) {
  return { baseUrl: c.baseUrl, model: c.model, hasKey: !!c.apiKey };
}
export async function saveConfig(dir: string, patch: Partial<Config>) {
  const current = await loadConfig(dir);
  const next = configSchema.parse({ ...current, ...patch });
  next.baseUrl = normalizeBaseUrl(next.baseUrl);
  if (next.baseUrl !== current.baseUrl && patch.apiKey === undefined)
    next.apiKey = "";
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await chmod(dir, 0o700);
  const tmp = path.join(dir, `config-${crypto.randomUUID()}.tmp`);
  await writeFile(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
  await rename(tmp, path.join(dir, "config.json"));
  await chmod(path.join(dir, "config.json"), 0o600);
  return publicConfig(next);
}
