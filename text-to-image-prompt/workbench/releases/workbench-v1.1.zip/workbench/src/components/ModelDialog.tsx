import React, { useEffect, useState } from "react";
import {
  Check,
  KeyRound,
  LoaderCircle,
  PlugZap,
  Trash2,
  ExternalLink,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { api } from "../api";
import type { PublicConfig } from "../../shared/contracts";
export function ModelDialog({
  open,
  onOpenChange,
  config,
  onConfig,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  config: PublicConfig | null;
  onConfig: (v: PublicConfig) => void;
}) {
  const [baseUrl, setBaseUrl] = useState("https://api.deepseek.com");
  const [model, setModel] = useState("");
  const [key, setKey] = useState("");
  const [models, setModels] = useState<{ id: string; name: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    if (open) {
      setBaseUrl(config?.baseUrl ?? "https://api.deepseek.com");
      setModel(config?.model ?? "");
      setKey("");
      setMessage("");
      setError("");
    }
  }, [open]);
  async function save(test = false) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const next = await api<PublicConfig>("config", {
        method: "PUT",
        body: JSON.stringify({
          baseUrl,
          model,
          ...(key ? { apiKey: key } : {}),
        }),
      });
      onConfig(next);
      setKey("");
      if (test) {
        const result = await api<{ models: { id: string; name: string }[] }>(
          "models",
          { method: "POST", body: "{}" },
        );
        setModels(result.models);
        setMessage(
          `连接成功，找到 ${result.models.length} 个模型。请选择后保存。`,
        );
      } else {
        setMessage("设置已保存到本机。");
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    setBusy(true);
    try {
      const c = await api<PublicConfig>("config", {
        method: "PUT",
        body: JSON.stringify({ apiKey: "" }),
      });
      onConfig(c);
      setKey("");
      setMessage("密钥已从本机删除。");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <div className="modal-icon">
          <PlugZap size={22} />
        </div>
        <DialogTitle className="dialog-title">连接你的创作引擎</DialogTitle>
        <DialogDescription className="dialog-description">
          使用 DeepSeek 生成场景与提示词，创作规则来自本地 skill。
        </DialogDescription>
        <div className="model-provider">
          <span className="provider-mark">D</span>
          <div>
            <strong>DeepSeek</strong>
            <small>OpenAI 兼容接口</small>
          </div>
          <span className="badge">本地配置</span>
        </div>
        <label className="control-label" htmlFor="base-url">
          接口地址
        </label>
        <input
          id="base-url"
          value={baseUrl}
          onChange={(e) => setBaseUrl(e.target.value)}
        />
        <label className="control-label" htmlFor="api-key">
          API Key{" "}
          {config?.hasKey && (
            <span className="success-text">
              <Check size={12} />
              已保存
            </span>
          )}
        </label>
        <input
          id="api-key"
          type="password"
          autoComplete="off"
          value={key}
          placeholder={
            config?.hasKey
              ? "已保存密钥；留空则保留"
              : "输入你的 DeepSeek API Key"
          }
          onChange={(e) => setKey(e.target.value)}
        />
        <label className="control-label" htmlFor="model-name">
          模型名称
        </label>
        {models.length > 0 && (
          <select
            aria-label="可用模型"
            value={models.some((x) => x.id === model) ? model : ""}
            onChange={(e) => setModel(e.target.value)}
          >
            <option value="">从可用模型中选择</option>
            {models.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        )}
        <input
          id="model-name"
          value={model}
          onChange={(e) => setModel(e.target.value)}
          placeholder="测试连接后选择，也可手动填写"
        />
        <p className="field-hint">
          <KeyRound size={12} />
          密钥只保存在本机配置中，不会写入创作历史或导出文件。
        </p>
        <a
          className="text-link"
          href="https://platform.deepseek.com/api_keys"
          target="_blank"
          rel="noreferrer"
        >
          前往 DeepSeek 获取 API Key <ExternalLink size={12} />
        </a>
        {error && (
          <p className="error-box" role="alert">
            {error}
          </p>
        )}
        {message && (
          <p className="success-box" role="status">
            {message}
          </p>
        )}
        <div className="modal-actions">
          <Button
            variant="ghost"
            size="icon"
            aria-label="删除密钥"
            disabled={!config?.hasKey || busy}
            onClick={remove}
          >
            <Trash2 size={16} />
          </Button>
          <span className="spacer" />
          <Button variant="outline" disabled={busy} onClick={() => save(true)}>
            {busy ? (
              <LoaderCircle className="spin" size={16} />
            ) : (
              <PlugZap size={16} />
            )}
            保存并测试
          </Button>
          <Button disabled={busy} onClick={() => save(false)}>
            保存设置
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
