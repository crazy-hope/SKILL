# 画外 · 提示词创作工作台 v1

基于项目中的 Midjourney 创意导演 skill，将九项设置集中为面板，通过 DeepSeek 构思五个场景、选择变化方式，生成三组完整中英文提示词。只生成文字，不自动提交生图。

## 打开工作台

需要 Node.js 22 或更高版本。保留本目录与上一级 skill 的相对位置，不要单独移动工作台。

macOS 可以双击本目录的 **启动工作台.command**；首次启动会安装依赖。关闭启动终端会停止服务。

也可以在本目录执行：

```sh
npm install
npm run dev
```

打开 http://127.0.0.1:4317 。仅本机可访问，不向局域网公开。端口占用时可执行 `PORT=4318 npm run dev`，并访问对应端口。浏览器草稿与历史按访问地址保存，建议固定使用一个地址。

正式运行可先执行 `npm run build`，然后 `npm start`。

## 第一次使用

1. 右上角点击「连接 DeepSeek」，填写 API Key，点击「保存并测试」。
2. 从返回的列表选择模型，或手动填写你有权限使用的型号，再保存设置。默认地址是 `https://api.deepseek.com`；兼容中转或本地服务可自行填写地址，需支持 Chat Completions 和 JSON Output。
3. 填写九项设置。表现方式、具体视觉风格和题材支持多选；自定义组合可用 `＋` 或逗号分隔，按回车或加号添加。自定义输入尚未添加前不计入已选方向。整体色彩／色调单独选择配色方向、自由选择或自定义；旧草稿缺少该项时需补选，历史成品仍可查看。
4. 点击「生成五个场景」，选择一个场景，再选择变化方式，生成完整提示词。
5. 在三个版本间切换，分别复制中文、英文，或复制全部、导出 MD/TXT。

创作元素可以留空。文化与内容现实性必须单独选择；不确定画幅可以请求建议后确认。填写 Midjourney 版本或明确选择沿用界面，不能把未知版本当作已确认。

「换一批」保留条件。修改意见会追加为本轮硬条件；可在左侧创作起点中修改或删除。改变设置后旧结果保留可读，但不能作为当前场景继续生成。请求失败时不会自动重试；可再次点击相应生成按钮。等待时可取消，或修改设置取消失效请求。

内容冲突一次澄清一处，回答会显示在「本轮已确认取舍」。版本／Personalize 参数冲突要求直接修改对应设置，避免文字取舍与实际后缀不一致。关闭个人化时，还需要自行关闭 Midjourney 界面的个人化开关。

## 数据保存

- API Key 保存在 `workbench/.local/config.json`，是本机明文配置（非加密保险库），文件权限 `600`、目录权限 `700`。浏览器只获得已配置状态，不会读取已保存密钥。设置窗口可删除密钥。
- `.local/`、环境文件、依赖及构建产物已排除 Git。开发服务也阻止通过文件 URL 读取 `.local/` 和环境文件。
- 更改接口地址但没有填写新密钥时，会清除原密钥，避免将它发给不同服务。
- 草稿与最近 50 次完成记录保存在当前浏览器 IndexedDB，不含密钥。历史可恢复、删除；清理浏览器数据会清除它们，重要结果请导出。
- 新建任务为空白设置；「沿用上次设置」需要明确点击。
- 发起生成时，创作设置及所需 skill 规则将发给配置的模型服务；界面勾选本身不调用模型。

## 与 skill 一起维护

工作台独立版本，不改 skill 的 `metadata.version`。根目录 `AGENTS.md` 已加入同步要求。

运行来源是 `SKILL.md`、`references/visual-direction.md`、`references/creative-engine.md`、`references/midjourney.md`。字段集中在 `shared/fields.ts`，类型与参数在 `shared/contracts.ts`，阶段在 `shared/session.ts`，输出适配在 `server/prompts.ts`。`skill-manifest.json` 是已核对来源的指纹，不是 skill 副本。

1. 审查 skill 差异，判断字段、选项、阶段、变化方式、参数和输出结构的影响；必要时更新工作台和测试。
2. 新增运行参考文件时，同步 `server/rules.ts` 的列表；不要漏掉被新规则要求读取的资料。
3. 完成审查与相关修改后，按下面命令更新指纹。**不能只更新指纹来消除同步提示。**
4. 运行 `npm run check`，更新工作台 CHANGELOG 和验证记录。

```sh
node --import tsx --input-type=module -e 'import {readSources} from "./server/rules.ts"; import {writeFile} from "node:fs/promises"; const s=await readSources(".."); await writeFile("skill-manifest.json", JSON.stringify({version:s.version,hash:s.hash,files:s.files},null,2)+"\n");'
npm run check
```

未核对的源文件变化会暂停新生成；草稿、历史、复制与导出仍可用。生成期间再次发生变化也不会交付混用版本的结果。面板不会由模型自动重建。

## 验证范围

`npm run check` 包含 Vitest/React Testing Library 流程与接口测试、TypeScript/生产构建、规则指纹检查。接口测试使用临时回环端口和模拟 DeepSeek 响应，不消耗真实 API 额度。

本次未配置真实 API Key，未进行真实 DeepSeek 生成联调；模型对艺术内容和双语语义的实际遵循仍需真实使用评估。浏览器验证与自动测试记录见 `docs/verification.md`。这些是文本、软件和交互验证，不是 Midjourney 生图效果验证。
